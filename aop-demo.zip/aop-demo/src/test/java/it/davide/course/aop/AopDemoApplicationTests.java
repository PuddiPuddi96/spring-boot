package it.davide.course.aop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AopDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
