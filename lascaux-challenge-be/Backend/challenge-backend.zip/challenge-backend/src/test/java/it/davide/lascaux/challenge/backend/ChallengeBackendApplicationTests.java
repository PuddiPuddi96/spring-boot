package it.davide.lascaux.challenge.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
